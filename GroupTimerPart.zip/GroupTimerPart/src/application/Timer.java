package application;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Timer extends Application
{
	Scene scene;
	VBox vBox;
	HBox hBox;
	Button sButton, rButton;
	Text text;
	Timeline timeline;
	int mins = 0, secs = 0, millis = 0;
	boolean sos = true;
	
	public static void main(String[] args) {
		launch(args);
	}

	void change(Text text) {
		if(millis == 1000) {
			secs++;
			millis = 0;
		}
		if(secs == 60) {
			mins++;
			secs = 0;
		}
		text.setText((((mins/10) == 0) ? "0" : "") + mins + ":"
		 	+ (((secs/10) == 0) ? "0" : "") + secs + ":" 
			+ (((millis/10) == 0) ? "00" : (((millis/100) == 0) ? "0" : "")) + millis++);
    }

	@Override
	public void start(Stage stage) {
		text = new Text("00:00:000");
		timeline = new Timeline(new KeyFrame(Duration.millis(1), new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
            	change(text);
			}
		}));
		timeline.setCycleCount(Timeline.INDEFINITE);
		timeline.setAutoReverse(false);
		sButton = new Button("Start");
		sButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	if(sos) {
            		timeline.play();
            		sos = false;
            		sButton.setText("Stop");
            	} else {
            		timeline.pause();
            		sos = true;
            		sButton.setText("Start");
            	}
            }
        });
		rButton = new Button("Reset");
		rButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	mins = 0;
            	secs = 0;
            	millis = 0;
            	timeline.pause();
            	text.setText("00:00:000");
            	if(!sos) {
            		sos = true;
            		sButton.setText("Start");
            	}
            }
        });
		hBox = new HBox(30);
		hBox.setAlignment(Pos.CENTER);
		hBox.getChildren().addAll(sButton, rButton);
		vBox = new VBox(30);
		vBox.setAlignment(Pos.CENTER);
		vBox.getChildren().addAll(text, hBox);
		scene = new Scene(vBox, 200, 150);
		stage.setScene(scene);
        stage.setTitle("Stopwatch");
		stage.show();
	}
}

/*import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public abstract class Timer implements ActionListener {
	
	JFrame frame = new JFrame();
	JButton startButton = new JButton("STOP");
	JButton resetButton = new JButton("RESET");
	
	JLabel timeLabel = new JLabel();
	int elapsedTime = 0;
	int seconds = 0;
	int minutes = 0;
	int hours = 0;
	boolean started  = false;
	String seconds_string = String.format("%02d",seconds);
	String minutes_string = String.format("%02d",minutes);
	String hours_string = String.format("%02d",hours);
	
	Timer timer = new Timer(1000, new ActionListener())
	{
		public void actionPerformed(ActionEvent e)
		{
			elapsedTime = elapsedTime+1000;
			hours = (elapsedTime/3600000);
			minutes = (elapsedTime/60000) % 60;
			seconds = (elapsedTime/1000) % 60;
			
			seconds_string = String.format("%02d", seconds);
			minutes_string = String.format("%02d", minutes);
			hours_string = String.format("%02", hours);
			timeLabel.setText(hours_string+":"+minutes_string+":"+seconds_string);
		  	
		}
		
	}

	
	Timer()
	{
		timeLabel.setText(hours_string+":"+minutes_string+":"+seconds_string);
		timeLabel.setBounds(100,100,200,100);
		timeLabel.setFont(new Font("Verdana",Font.PLAIN,35));
		timeLabel.setBorder(BorderFactory.createBevelBorder(1));
		timeLabel.setOpaque(true);
		timeLabel.setHorizontalAlignment(JTextField.CENTER);
		
		startButton.setBounds(100,200,100,50);
		startButton.setFont(new Font("Ink Free",Font.PLAIN,20));
		startButton.setFocusable(false);
		startButton.addActionListener(this);
		
		resetButton.setBounds(200,200,100,50);
		resetButton.setFont(new Font("Ink Free",Font.PLAIN,20));
		resetButton.setFocusable(false);
		resetButton.addActionListener(this);
		
		frame.add(startButton);
		frame.add(resetButton);
		frame.add(timeLabel);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(420,420);
		frame.setLayout(null);
		frame.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==startButton)
		{
			startTimer();
			if(started == false)
			{
				started = true;
				startButton.setText("STOP");
				startTimer();
			}
			else
			{
				started = false;
				startButton.setText("START");
				stopTimer();
			}
		}
		if(e.getSource()==resetButton)
		{
			started = false;
			startButton.setText("Start");
			resetTimer();
		}
	}
	void startTimer()
	{
		timer.startTimer();
		
	}
	void stopTimer()
	{
		timer.stopTimer();
	}
	void resetTimer()
	{
		timer.stopTimer();
		elapsedTime = 0;
		seconds = 0;
		minutes = 0;
		hours = 0;
		
		seconds_string = String.format("%02d", seconds);
		minutes_string = String.format("%02d", minutes);
		hours_string = String.format("%02", hours);
		timeLabel.setText(hours_string+":"+minutes_string+":"+seconds_string);
	  	
	}
	

}
*/
